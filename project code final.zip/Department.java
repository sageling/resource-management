package resourceManagement;
import java.util.*;

public class Department {
	String name;
	double totalSpent; // Priority Value (used in priority queue)

	Queue<Item> itemsDesired;
	Queue<Item> itemsReceived;
	Queue<Item> itemsRemoved;

	public Department(String name) {
		this.name = name;
		this.totalSpent = 0;

		itemsDesired = new LinkedList<>();
		itemsReceived = new LinkedList<>();
		itemsRemoved = new LinkedList<>();
	}
    
	Item getDesired() {
		return itemsDesired.peek();
	}
    
	void giveItem() {
		totalSpent += itemsDesired.peek().getPrice();
		itemsReceived.add(itemsDesired.poll());
	}
    
	void denyItem() {
		itemsRemoved.add(itemsDesired.poll());
	}
    
	void giveScholarship(double value) {
		totalSpent += value;
		itemsReceived.add(new Item("Scholarship", value));
	}

	void printReport(double totalBudget) {

		System.out.println("\n" + name);
		System.out.printf("%-30s $%15.2f\n", "Total Spent =", totalSpent);
		
		double percent = (totalSpent / totalBudget) * 100;
		System.out.printf("%-30s %16.2f%s\n", "Percent of Budget =", percent, "%");
		
		System.out.println("-------------------------------------------------");
		//
		System.out.printf("%30s\n", "ITEMS RECEIVED");
		for (Item item : itemsReceived) {
			System.out.printf("%-30s $%15.2f\n", item.getName(), item.getPrice());
		}

		System.out.printf("%32s\n", "ITEMS NOT RECEIVED");
		for (Item item : itemsRemoved) {
			System.out.printf("%-30s $%15.2f\n", item.getName(), item.getPrice());
		}
		System.out.println();
	}

}
