/*
 * Data Structures Project
 * Contributors: Jany Hernandez, Nicholas Malovich
 */
package resourceManagement;
import java.io.File;
import java.util.*;
import java.io.FileNotFoundException;
class PriorityQueue {
   Node top;
   Department addDepartment(File input) {
       try {
           Scanner scnr = new Scanner(input);
           Department newDep = new Department(scnr.next());
           while (scnr.hasNext()) {
               Item item = new Item(scnr.next(), scnr.nextDouble());
               newDep.itemsDesired.add(item);
           }
           scnr.close();  //close before return
          
           addDepartment(newDep); // use simpler version
           return newDep;
       } catch (FileNotFoundException e) {
           System.out.println(e.getMessage());
       }
       return null;
   }
   void addDepartment(Department department) {
       Node newNode = new Node(department);
       if (top == null || department.totalSpent < top.department.totalSpent) {
           newNode.next = top;
           top = newNode;
           return;
       }
       Node current = top;
       while (current.next != null &&
               department.totalSpent >= current.next.department.totalSpent) {
           current = current.next;
       }
       newNode.next = current.next;
       current.next = newNode;
   }
}
class Node {
   Department department;
   Node next;
   Node(Department department) {
       this.department = department;
   }
}
class resourceManagement {
   public static void main(String[] args) {
       PriorityQueue pq = new PriorityQueue();
       final double STARTING_BUDGET = 41850;
       double budget = STARTING_BUDGET;
       ArrayList<String> purchased = new ArrayList<>();
       File[] textFiles = new File[4];
       textFiles[1] = new File("Department-PhysicsAndAstronomy.txt");
       textFiles[2] = new File("Department-Mathematics.txt");
       textFiles[0] = new File("Department-ComputerScience.txt");
       textFiles[3] = new File("Department-Chemistry.txt");
       ArrayList<Department> departments = new ArrayList<>();
       for (int i = 0; i < textFiles.length; i++) {
           Department d = pq.addDepartment(textFiles[i]);
           if (d != null) {
               departments.add(d);
           }
       }
       while (budget > 0 && pq.top != null) {
           Node currentNode = pq.top;
           pq.top = currentNode.next;
           Department dept = currentNode.department;
           Item nextItem = dept.getDesired();
           if (nextItem == null) {
               double amount = Math.min(1000, budget);
               dept.giveScholarship(amount);
               budget -= amount;
               purchased.add(String.format("%-25s %-25s $%,10.2f", dept.name, "Scholarship", amount));
           }
           else if (nextItem.getPrice() <= budget) {
               budget -= nextItem.getPrice();
               dept.giveItem();
               purchased.add(String.format("%-25s %-25s $%,10.2f", dept.name, nextItem.getName(), nextItem.getPrice()));
           }
           else {
               dept.denyItem();
           }
           pq.addDepartment(dept);
       }
       System.out.println("ITEMS PURCHASED\n");
       for (String s : purchased) {
           System.out.println(s);
       }
       System.out.println("\nDEPARTMENT REPORTS");
       for (Department d : departments) {
           d.printReport(STARTING_BUDGET);
       }
   }
}
