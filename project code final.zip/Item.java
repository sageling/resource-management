package resourceManagement;

public class Item {
    String name;
    double price;

    public Item(String name, double price) {
        this.name = name;
        this.price = price;
    }
    double getPrice() {
        return price;
    }
    
    String getName() {
        return name;
    }
}

